extern void readBMP(const char *path, int *Width, int *Height, unsigned char ImageRGB[2000][2000][3]);
extern void saveWithLastHeader(unsigned char ***Image, int width, int height, char *address);